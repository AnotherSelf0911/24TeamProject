package data;

public class Member{
		
	// 회원 가입 시 넣어지는 정보들
	String memberName;	// 이름
	String memberGender;// 성별
	int memberAge;		// 나이
	float startWeight;  // 첫날 몸무게
	float memberWeight; // 몸무게
	float memberLength; // 키
	String startDate;	// 시작일 (회원가입일)
	String memberID;	// 회원 아이디
	String memberPW;	// 회원 비밀번호
	
	
	
	int days;			// 회원가입일로부터 몇일 지났는지
	int exerciseDays;	// 운동한 날짜
	String memberGrade;	// 회원 등급
	String memberExerciseDiff;	// 회원 운동 강도
	float memberBMI; // BMI 수치
	
	

	public Member() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Member(String memberName, String memberGender, int memberAge, float startWeight, float memberWeight,
			float memberLength, String startDate, String memberID, String memberPW, int days, int exerciseDays,
			String memberGrade, String memberExerciseDiff, float memberBMI) {
		super();
		this.memberName = memberName;
		this.memberGender = memberGender;
		this.memberAge = memberAge;
		this.startWeight = startWeight;
		this.memberWeight = memberWeight;
		this.memberLength = memberLength;
		this.startDate = startDate;
		this.memberID = memberID;
		this.memberPW = memberPW;
		this.days = days;
		this.exerciseDays = exerciseDays;
		this.memberGrade = memberGrade;
		this.memberExerciseDiff = memberExerciseDiff;
		this.memberBMI = memberBMI;
	}



	public String getMemberName() {
		return memberName;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	public String getMemberGender() {
		return memberGender;
	}


	public void setMemberGender(String memberGender) {
		this.memberGender = memberGender;
	}


	public int getMemberAge() {
		return memberAge;
	}


	public void setMemberAge(int memberAge) {
		this.memberAge = memberAge;
	}


	public float getStartWeight() {
		return startWeight;
	}


	public void setStartWeight(float startWeight) {
		this.startWeight = startWeight;
	}


	public float getMemberWeight() {
		return memberWeight;
	}


	public void setMemberWeight(float memberWeight) {
		this.memberWeight = memberWeight;
	}


	public float getMemberLength() {
		return memberLength;
	}


	public void setMemberLength(float memberLength) {
		this.memberLength = memberLength;
	}


	public String getStartDate() {
		return startDate;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getMemberPW() {
		return memberPW;
	}


	public void setMemberPW(String memberPW) {
		this.memberPW = memberPW;
	}


	public int getDays() {
		return days;
	}


	public void setDays(int days) {
		this.days = days;
	}


	public int getExerciseDays() {
		return exerciseDays;
	}


	public void setExerciseDays(int exerciseDays) {
		this.exerciseDays = exerciseDays;
	}


	public String getMemberGrade() {
		return memberGrade;
	}


	public void setMemberGrade(String memberGrade) {
		this.memberGrade = memberGrade;
	}


	public String getMemberExerciseDiff() {
		return memberExerciseDiff;
	}


	public void setMemberExerciseDiff(String memberExerciseDiff) {
		this.memberExerciseDiff = memberExerciseDiff;
	}


	public float getMemberBMI() {
		return memberBMI;
	}


	public void setMemberBMI(float memberBMI) {
		this.memberBMI = memberBMI;
	}


	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}


	public String getMemberID() {
		return memberID;
	}
	

	
	
}