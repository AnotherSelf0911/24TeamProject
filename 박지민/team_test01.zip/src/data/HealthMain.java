package data;

import de.LoginMenu2;

public class HealthMain {

	public static void main(String[] args) {
		
		LoginMenu2 login = new LoginMenu2();
		
	}

}
